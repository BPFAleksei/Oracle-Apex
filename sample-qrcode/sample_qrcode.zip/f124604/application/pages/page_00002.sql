prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.2'
,p_default_workspace_id=>41247636517101868016
,p_default_application_id=>124604
,p_default_id_offset=>0
,p_default_owner=>'WKSP_SOFERTEST'
);
wwv_flow_api.create_page(
 p_id=>2
,p_user_interface_id=>wwv_flow_api.id(41284197692259104620)
,p_name=>'Reports'
,p_alias=>'REPORTS'
,p_step_title=>'Reports'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'#APP_IMAGES#qrcode.min.js'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ALEKSEI.ESCOBAR@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20211013010350'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(41286126709936135106)
,p_name=>'Report 1'
,p_template=>wwv_flow_api.id(41284108089033104576)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       NAME,',
'       DESCRIPTION,',
'       SKU,',
'       UNIT,',
'       UNIT_PRICE,',
'       UNIT_PRICE AS QRCODE',
'  from PRODUCTS'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(41284138177959104593)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_csv_output=>'Y'
,p_csv_output_link_text=>'Download'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(41286127175484135107)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_column_heading=>'Id'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(41286127502578135107)
,p_query_column_id=>2
,p_column_alias=>'NAME'
,p_column_display_sequence=>20
,p_column_heading=>'Name'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(41286127947571135107)
,p_query_column_id=>3
,p_column_alias=>'DESCRIPTION'
,p_column_display_sequence=>30
,p_column_heading=>'Description'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(41286128327318135108)
,p_query_column_id=>4
,p_column_alias=>'SKU'
,p_column_display_sequence=>40
,p_column_heading=>'Sku'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(41286128734892135108)
,p_query_column_id=>5
,p_column_alias=>'UNIT'
,p_column_display_sequence=>50
,p_column_heading=>'Unit'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(41286129168724135108)
,p_query_column_id=>6
,p_column_alias=>'UNIT_PRICE'
,p_column_display_sequence=>60
,p_column_heading=>'Unit Price'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(41294215672062220901)
,p_query_column_id=>7
,p_column_alias=>'QRCODE'
,p_column_display_sequence=>70
,p_column_heading=>'Qrcode'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<div id="qr_#ID#" class="qrcode" data-qrcode="QR#ID#"></div>'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(41294215934402220904)
,p_name=>'New'
,p_event_sequence=>10
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(41294216125675220906)
,p_event_id=>wwv_flow_api.id(41294215934402220904)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'hola'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(41294216049764220905)
,p_event_id=>wwv_flow_api.id(41294215934402220904)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''.qrcode'').each(function(){',
'	var qrcode = new QRCode($(this).attr(''id''),{',
'	text:$(this).attr(''data-qrcode''),',
'	width:65,',
'	height:65,',
'	colorDark:"#000000",',
'	colorLight:"#ffffff",',
'	correctLevel: QRCode.CorrectLevel.H',
'	});',
'});'))
);
wwv_flow_api.component_end;
end;
/
